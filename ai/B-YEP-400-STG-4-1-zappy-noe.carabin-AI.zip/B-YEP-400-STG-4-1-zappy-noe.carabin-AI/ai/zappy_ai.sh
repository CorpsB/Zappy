#!/bin/bash

python3 -m ai.main "$@"
