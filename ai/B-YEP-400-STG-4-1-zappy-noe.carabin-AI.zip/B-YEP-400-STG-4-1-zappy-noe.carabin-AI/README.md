./zappy_server -p 4242 -x 42 -y 42 -n TeamA TeamB -c 20 -f 28 --auto-start on --display-eggs true

./zappy_ai -h 127.0.0.1 -p 4242 -c 10 -n TeamA

./zappy_gui -h 127.0.0.1 -p 4242
